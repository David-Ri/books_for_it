package com.example.demo.service;

import com.example.demo.entity.User;
import com.mongodb.client.result.UpdateResult;
import reactor.core.publisher.Mono;

/**
 * Copyright (C), 2019-2019, XXX有限公司
 * FileName: UserService
 * Author:   longzhonghua
 * Date:     3/27/2019 2:24 PM
 * Description: ${DESCRIPTION}
 * History:
 * <author>          <time>          <version>          <desc>
 * 作者姓名           修改时间           版本号              描述
 */
public interface UserService {


}
