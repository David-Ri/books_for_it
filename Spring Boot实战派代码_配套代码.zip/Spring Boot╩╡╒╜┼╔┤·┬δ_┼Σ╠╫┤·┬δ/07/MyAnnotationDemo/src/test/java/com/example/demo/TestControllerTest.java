package com.example.demo;

import static org.junit.Assert.*;

/**
 * Copyright (C), 2019-2019, XXX有限公司
 * FileName: TestControllerTest
 * Author:   longzhonghua
 * Date:     5/19/2019 9:16 PM
 * Description:
 * History:
 * <author>          <time>          <version>          <desc>
 * 作者姓名           修改时间           版本号              描述
 */
public class TestControllerTest {

}