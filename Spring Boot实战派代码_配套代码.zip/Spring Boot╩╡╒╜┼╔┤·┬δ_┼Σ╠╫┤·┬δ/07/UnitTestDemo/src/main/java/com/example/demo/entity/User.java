package com.example.demo.entity;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;



/**
 * Copyright (C), 2019-2019, XXX有限公司
 * FileName: User
 * Author:   longzhonghua
 * Date:     3/20/2019 10:17 PM
 * Description: ${DESCRIPTION}
 * History:
 * <author>          <time>          <version>          <desc>
 * 作者姓名           修改时间           版本号              描述
 */
@Data

public class User {
    private String name;
    private  int age;
}