package com.example.demo.entity;

/**
 * Copyright (C), 2019-2019, XXX有限公司
 * FileName: User
 * Author:   longzhonghua
 * Date:     2019/5/5 22:40
 * Description:
 * History:
 * <author>          <time>          <version>          <desc>
 * 作者姓名           修改时间           版本号              描述
 */

public class User {
    private long id;
    private String name;

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public User(long id, String name) {
        this.id = id;
        this.name = name;
    }
}
